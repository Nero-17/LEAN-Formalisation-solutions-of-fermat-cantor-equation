# R021: proof chain for the universal last-transition bound

**PROVED: the mathematical reductions and every required certificate have passed independent review and exact verification.** The final dependency check returned COMPLETE VERIFIED DEPENDENCY CHAIN on 2026-10-21 at 11:40 UTC. This document belongs to the same single R021 archive; RESEARCH_RECORD.md retains the complete history, corrections, and failed routes.

## Statement and meaning of the bound

Let C_lambda be the compact attractor of x -> lambda x and x -> 1-lambda+lambda x, and let

    E_(n,lambda) = {(x,y) in C_lambda × C_lambda : x^n+y^n=1}.

The exponent range in this project is every real n>1. The requested inequality, now proved, is

    lambda_max(n) <= (sqrt(3)-1)/2,

where lambda_max is the supremum of the parameters in (0,1/2] for which E_(n,lambda) has zero Hausdorff dimension. The proved direct assertion is

    dim_H E_(n,lambda)>0
    for every real n>1 and every (sqrt(3)-1)/2 <= lambda <= 1/2.

There is no monotonicity assumption on the dimension as lambda varies. Positivity at the single proposed constant would not prove a last-transition bound. The certificates cover the entire contraction interval above the constant. At lambda=1/2, C_lambda=[0,1], and the Fermat arc has dimension one; this endpoint needs no Cantor separation argument.

## Analytic positive-dimension criterion

Suppose 0<lambda<1/2 and f,g are increasing C¹ functions on [0,1], with positive derivatives. Subtract their values at zero. If the entire cross-variable derivative-ratio interval g'(t)/f'(s) is strictly above 1 and lies inside either

    (1/lambda-1-lambda, 1/(1-lambda))

or

    (1/lambda-1, 1/(1-lambda-lambda²)),

then every strict interior level of f(s)+g(t) has a positive-dimensional intersection with C_lambda². Its strict finite return construction persists under sufficiently small C¹ perturbations. Only separable perturbations are needed for the present application.

Here is why the conclusion is dimension positivity, rather than just existence or uncountability. The four first-generation image hulls are ordered 00,10,01,11 and cover their parent hull with strict adjacent overlap. A trajectory avoiding overlap can remain in the middle child 10 only by continuing in 10 forever; the same holds for 01. This follows from

    f(lambda)+g(lambda)>f(1-lambda²),
    g(1-lambda)<f(1)+g(lambda²).

A 00-to-11 transition is excluded by

    f(1-lambda)<f(lambda²)+g(lambda),

and reflection excludes the reverse transition. The constant middle tails are excluded by the additional lower-band or upper-band inequality. Thus every strict interior level reaches a strict overlap after finitely many steps.

For uniform branching, initially normalize min f'=1 and fix strict ratio bounds 1<L<=g'/f'<=U in one band. Consider the closed Lipschitz family defined by 1<=f'<=U/L, L<=g'<=U and the cross-variable increment bounds. Restrictions divided by their cylinder scale preserve these bounds; it is not required that each restricted member still have min f'=1. This family is compact in the uniform topology. Choose a fixed positive delta with

    delta < lambda(1+L)/(1+lambda).

The all-zero-prefix images of the central domains [delta,f(1)+g(1)-delta] overlap strictly and reach every lower interior level; reflection reaches every upper interior level. Each of the two overlap children therefore returns strictly to the same type of central domain. Compactness of function pairs together with central levels gives a uniform finite maximum return length and a positive return margin. Iterating two incomparable returning cylinders produces a separated binary tree and a positive Frostman exponent. These finite strict conditions also prove the required C¹ stability.

The complete inequalities and compactness argument are in scale_matching.md, “Analytic completion of the all-interior slope bands.” A separate third-view audit, including the central-domain invariance, is in adversarial_last.md. This analytic theorem is a mathematical input to the computer-assisted portion; it is not inferred from numerical branching counts.

## Three types of source certificate

A source consists of two positive Cantor cylinders of depths p,q, with hull endpoints u_-,u_+ and v_-,v_+. Their endpoints are explicit polynomials in lambda. Each certificate specifies an orientation and one analytic derivative band.

An actual-curve source checks

    u_-^n+v_-^n < 1 < u_+^n+v_+^n,

and the normalized derivative ratio, or its reciprocal, inside the chosen band. The default ratio enclosure is

    [lambda^(q-p)(v_-/u_+)^(n-1),
     lambda^(q-p)(v_+/u_-)^(n-1)].

The analytic criterion applies directly.

A raw endpoint source uses fixed integers j and k>=0 and the limiting equation

    u^n = n lambda^(j-kn) v.

It checks strict corner crossing u_-^n < n lambda^(j-kn)v_+ and u_+^n > n lambda^(j-kn)v_-, and the default ratio

    [lambda^(j-kn+q-p)u_+^(1-n),
     lambda^(j-kn+q-p)u_-^(1-n)].

A logarithmic endpoint source uses the zero-equivalent expression

    n log u - log v - log n - (j-kn)log lambda.

Its corner conditions are equivalent, but its default first-to-second ratio is different:

    [n lambda^(p-q)v_-/u_+, n lambda^(p-q)v_+/u_-].

The second coordinate is reflected to make both functions increasing. Reflection preserves the central Cantor set. The source tag determines which ratio convention applies; neither the producer nor the independent checker substitutes the raw ratio for the logarithmic ratio.

For every fixed real n, choose positive integers t tending to infinity with dist(nt,Z)->0. Rational exponents allow exact denominator multiples; irrational exponents use elementary recurrence modulo one. Set the first endpoint scale to k+t and the second to j+nearestinteger(nt). The embedded coordinates

    x=lambda^(k+t)u,
    y=1-lambda^(j+nearestinteger(nt))v

belong to C_lambda. The normalized actual equation converges in C¹ to the raw endpoint model. For a logarithmic source, use instead the exactly zero-equivalent actual expression

    n log u - log([1-(1-lambda^m v)^n]/lambda^(nK)),

where K and m are the displayed first and second scales. Its C¹ limit is the certified logarithmic source. The source coordinates stay bounded away from zero, so the logarithm and its derivative are controlled. Strict source inequalities persist at sufficiently deep, fixed scales. That one fixed affine embedding preserves Hausdorff dimension. No assertion about the dimension of a limit of sets is used.

All these actual expressions are still separable. Thus one may simply apply the analytic criterion again after passing its strict corner and derivative inequalities to a sufficiently deep scale. The universal bound does not require the more general statement about nonseparable perturbations.

## Why rational rectangle endpoints control all real exponents

Each stored record covers a closed rational rectangle in (n,lambda), not a sampled parameter pair. For fixed lambda, the endpoint logarithmic corner residual has exponent derivative

    log u + k log lambda - 1/n < 0.

The raw corner residual and its logarithmic counterpart have the same sign, since both sides of the source equation are positive. Thus these logarithmic sign checks also verify raw endpoint sources.

The raw endpoint ratio has logarithmic exponent derivative -k log lambda-log u>=0. The logarithmic endpoint ratio is proportional to n. Actual corner sums decrease with n, while the logarithm of each actual ratio endpoint is affine in n. Therefore checking both exponent endpoints rigorously controls every real exponent between them, including irrational exponents.

In lambda, the independent verifier uses rational interval bounds and centered mean-value bounds. For the logarithmic corner residual its derivative is exactly

    n u'(lambda)/u(lambda) - (j-kn)/lambda - v'(lambda)/v(lambda).

Cylinder polynomials and their derivatives are rebuilt independently from positional digits. Logarithms use binary range reduction and 110 terms of the atanh series with a rigorous remainder. Exponentials use 80 positive Taylor terms, a rigorous tail, and repeated squaring. All arithmetic rounds outward on integer intervals with denominator 10^60. Search computations may use floating point to propose a source, but floating point does not decide acceptance.

For the upper exponent interval, parent_continuous_tight_audit.py intersects the natural cylinder-polynomial enclosure with its midpoint value plus the radius times its derivative enclosure. Both contain the exact polynomial values by the mean-value theorem, so their intersection is rigorous. Upper endpoints include the added lambda^depth term and its derivative. This reduces unnecessary subdivisions near cylinder endpoints close to one; all source inequalities and the coverage sweep remain identical. The change received a separate mathematical and code review.

After validating every source, the independent checker sweeps all exponent boundary events. In each intervening exponent strip it checks that the active contraction intervals cover from a rational lower enclosure of (sqrt(3)-1)/2 to 1/2 without a gap. Thus it verifies the entire two-dimensional cover independently of the producer's pending-state bookkeeping.

## Near-one exponents and the unbounded exponent tail

The interval 1<n<=6/5 is established by analytic source families and a small finite exception list. For a reduced rational p/q, the available coefficient exponents form (1/q)Z; near one, 1/q<=n-1. Explicit strict source windows are wider than this spacing. Irrational exponents have dense coefficient phases. Monotonicity in lambda reduces the remaining inequalities to exact rational-power comparisons. The exceptional exponents 7/6 and 6/5 use complete actual-curve contraction covers. All reductions, exception enumerations, and monotonicity arguments are in geometric_uniform.md §§13,14,16, with third-view audit in adversarial_last.md. parent_near_one_audit.py verifies the exact comparisons and enumeration. This supplies a full real interval, not only a list of rationals.

For n>=500, write n=lambda^(-m)t with 1<=t<1/lambda. The main tail certificate covers every scale lambda^(-m)>=1000. Finite logarithmic phase intervals, taken modulo -log lambda, cover the whole coefficient phase circle. Every source interval satisfies the analytic derivative criterion. A cyclic chain of strict interval overlaps covers the circle, hence hits the particular phase required by the exponent.

The finite-scale comparison is exact: for nonnegative A,B the function

    Z log((Z+A)/(Z+B))

is monotone in Z, with direction determined by A-B. It follows by writing it as the integral of Z/(Z+s) from B to A. Consequently all Z above a declared lower bound are controlled by the finite endpoint and the limit at infinity. Both comparisons are certified. The allowed endpoint depth is also checked, ensuring that every inserted source is a genuine Cantor cylinder.

If lambda^(-m)<1000 and n>=500, only m=6,7,8,9 remain. Indeed c^(-6)<500 for c=(sqrt(3)-1)/2, while 2^10>1000. Their contraction ranges lie between 1000^(-1/m) and 500^(-1/(m+1)), intersected with [c,1/2]. On a rational slab [l,u], it suffices to use the enlarged range

    scale >= floor(u^(-m)),
    max(1,500 l^m) <= t <= 1/l.

The initial lower endpoint in the coverage check is rounded downward, not upward. Seventy-five finite slabs supplement the 36 full-tail slabs. The parent independently replays every phase, derivative, endpoint-insertion, and interval-union check. The complete tail proof and correction history are in adversarial_last.md.

## Final dependency chain and reproducibility

The completed chain consists of the near-one analytic argument; five consecutive continuous covers [6/5,2], [2,10], [10,100], [100,250], [250,500]; and the n>=500 tail. All five independent coverage reports pass, have the stated exact endpoints, and match the data hashes. The final manifest universal_bound_verification.json was generated by verify_universal_bound.py, which also checks integer source scales and valid Cantor digit words. Missing reports cause failure rather than a partial success.

| Exponent interval | Certificate rectangles | Independently checked subrectangles | Exact exponent strips |
|---|---:|---:|---:|
| [6/5,2] | 152 | 165 | 48 |
| [2,10] | 1905 | 3513 | 493 |
| [10,100] | 13369 | 18693 | 1842 |
| [100,250] | 21855 | 31840 | 2017 |
| [250,500] | 51959 | 53067 | 2553 |

Thus 89240 continuous rectangles, verified using 107278 subrectangles, cover the compact exponent range. The separate unbounded tail uses 33755 sources in 36 full-scale slabs and 22859 sources in 75 finite-scale slabs. The near-one proof additionally uses the complete 67-record and 74-record covers for 7/6 and 6/5. These are exact interval certificates, not a sampling argument.

From this directory, with Python 3 and its standard library:

    python verify_universal_bound.py

checks the complete accepted dependency chain and data hashes. Each constituent checker was already run in full before this final aggregation; the default invocation does not repeat those computations. To recompute every required numerical certificate with the independent checkers:

    python verify_universal_bound.py --replay

The latter writes universal_bound_replay.log. Floating-point search programs and NumPy are not needed for verification. The replay verifies the finite inequalities; the analytic theorem, exponent monotonicity, and scale-transfer arguments above remain explicit mathematical parts of the proof.

The resulting conclusion is a computer-assisted proof for every real n>1. It is not a Lean formalisation and does not determine the exact value of lambda_max(n).

For each fixed n, an accepted strict source at lambda=c also persists on some interval immediately below c, because the cylinder endpoints and finite strict return inequalities depend continuously on lambda. Combining this local persistence with positivity for all lambda>=c gives the pointwise strengthening lambda_max(n)<c. This argument does not assert one uniform positive gap below c for all n.

In particular, the final theorem is

\[
\boxed{\lambda_{\max}(n)<\frac{\sqrt3-1}{2}\qquad\text{for every real }n>1.}
\]

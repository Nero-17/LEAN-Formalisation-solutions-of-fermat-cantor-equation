"""Independent real-exponent audit with centered cylinder endpoint enclosures.

Source inequalities, integer interval arithmetic, and coverage sweep are unchanged
from parent_continuous_cover_audit.py. Only polynomial endpoint value enclosures
are tightened by intersecting two independently valid interval enclosures.
"""
from parent_cubic_cover_verify import B,S,cylinder
from parent_phase_audit import C
from fractions import Fraction as Q
from functools import lru_cache
from pathlib import Path
import json,time,hashlib,sys
BASE=Path(__file__).parent
@lru_cache(None)
def unit_log(value):
    assert 1<=value<=2
    z=B((value-1)/(value+1));term=z;total=B(0)
    for j in range(110):
        total=total+2*term/(2*j+1);term=term*z*z
    remainder=2*term/(221*(1-z*z))
    return B(total.lo,total.hi+remainder.hi,True)
@lru_cache(None)
def reduced_log(raw):
    value=Q(raw,S);assert value>0
    shift=0
    while value>2:value/=2;shift+=1
    while value<1:value*=2;shift-=1
    return unit_log(value)+shift*unit_log(Q(2))
@lru_cache(None)
def log_range(lo,hi):return B(reduced_log(lo).lo,reduced_log(hi).hi,True)
@lru_cache(None)
def exp_point(raw):
    if raw<0:return B(1)/exp_point(-raw)
    squarings=max(1,raw.bit_length()-S.bit_length()+2)
    x=B(Q(raw,2**squarings*S));assert x.hi<S
    term=total=B(1)
    for j in range(1,81):term=term*x/j;total=total+term
    result=total+term*x/81/(1-x/82)
    # Lower bound drops the upper-only tail contribution.
    result=B(total.lo,result.hi,True)
    for _ in range(squarings):result=result*result
    return result
def power(x,r):
    r=Q(r)
    if r==0:return B(1)
    z=log_range(x.lo,x.hi)*r
    return B(exp_point(z.lo).lo,exp_point(z.hi).hi,True)
def natural_bounds(w,d,l,upper=False):
    value=B(0);derivative=B(0)
    for j in range(d):
        if w>>(d-j-1)&1:
            value=value+(1-l)*l**j
            derivative=derivative-l**j
            if j:derivative=derivative+j*(1-l)*l**(j-1)
    if upper:value=value+l**d;derivative=derivative+d*l**(d-1)
    return value,derivative

def bounds(w,d,l,upper=False):
    value,derivative=natural_bounds(w,d,l,upper)
    # The represented input interval is [l.lo/S,l.hi/S], including all
    # initial outward rounding. Its exact midpoint and symmetric radius
    # are rational; B rounds both of these outward as well.
    midpoint=B(Q(l.lo+l.hi,2*S))
    radius=B(Q(l.lo-l.hi,2*S),Q(l.hi-l.lo,2*S))
    center,_=natural_bounds(w,d,midpoint,upper)
    centered=center+radius*derivative
    left=max(value.lo,centered.lo)
    right=min(value.hi,centered.hi)
    assert left<=right, ('empty endpoint enclosure',w,d,upper,l.lo,l.hi)
    return B(left,right,True),derivative

def verify(row,lo,hi):
    l=B(lo,hi);mid=B((lo+hi)/2);radius=B(-(hi-lo)/2,(hi-lo)/2)
    p,q,w,vw=row['p'],row['q'],row['wx'],row['wy']
    assert row.get('k',0)>=0
    u,du=bounds(w,p,l);U,dU=bounds(w,p,l,True);v,dv=bounds(vw,q,l);V,dV=bounds(vw,q,l,True)
    um,_=bounds(w,p,mid);Um,_=bounds(w,p,mid,True);vm,_=bounds(vw,q,mid);Vm,_=bounds(vw,q,mid,True)
    def logarithm(x):return log_range(x.lo,x.hi)
    for n in {Q(row['nlo']),Q(row['nhi'])}:
        if row.get('source')=='actual':
            f0=power(um,n)+power(vm,n)-1+radius*n*(power(u,n-1)*du+power(v,n-1)*dv)
            f1=power(Um,n)+power(Vm,n)-1+radius*n*(power(U,n-1)*dU+power(V,n-1)*dV)
            loglow=(q-p)*logarithm(l)+(n-1)*(logarithm(v)-logarithm(U))
            loghigh=(q-p)*logarithm(l)+(n-1)*(logarithm(V)-logarithm(u))
        else:
            e=row['j']-row['k']*n
            f0=n*logarithm(um)-logarithm(B(n))-e*logarithm(mid)-logarithm(Vm)+radius*(n*du/u-e*(B(1)/l)-dV/V)
            f1=n*logarithm(Um)-logarithm(B(n))-e*logarithm(mid)-logarithm(vm)+radius*(n*dU/U-e*(B(1)/l)-dv/v)
            if row.get('source')=='log_endpoint':
                loglow=logarithm(B(n))+(p-q)*logarithm(l)+logarithm(v)-logarithm(U)
                loghigh=logarithm(B(n))+(p-q)*logarithm(l)+logarithm(V)-logarithm(u)
            else:
                loglow=(e+q-p)*logarithm(l)-(n-1)*logarithm(U)
                loghigh=(e+q-p)*logarithm(l)-(n-1)*logarithm(u)
        if f0.hi>=0 or f1.lo<=0:return False
        if row['swapped']:loglow,loghigh=-loghigh,-loglow
        lower=B(1)/l-1-l if row['band']==0 else B(1)/l-1
        upper=B(1)/(1-l) if row['band']==0 else B(1)/(1-l-l*l)
        threshold=logarithm(B(max(S,lower.hi),max(S,lower.hi),True))
        if loglow.lo<=threshold.hi or loghigh.hi>=logarithm(upper).lo:return False
    return True
def check(row,lo,hi,depth=0):
    if verify(row,lo,hi):return 1
    assert depth<15,('failed',row,lo,hi)
    mid=(lo+hi)/2
    return check(row,lo,mid,depth+1)+check(row,mid,hi,depth+1)
if __name__=='__main__':
    path=BASE/(sys.argv[1] if len(sys.argv)>1 else 'continuous_small_n_cover.jsonl')
    rows=[json.loads(x) for x in path.read_text().splitlines() if x];start=time.time();sub=0
    for i,row in enumerate(rows):
        sub+=check(row,Q(row['lo']),Q(row['hi']))
        if i%20==0:print('boxes',i+1,'subboxes',sub,'seconds',round(time.time()-start,1),flush=True)
    events={}
    for i,row in enumerate(rows):
        nlo,nhi=Q(row['nlo']),Q(row['nhi']);assert nlo<nhi
        interval=(Q(row['lo']),Q(row['hi']));assert interval[0]<interval[1]
        events.setdefault(nlo,[]).append((i,interval))
        events.setdefault(nhi,[]).append((i,None))
    nbreaks=sorted(events);active={}
    for a,b in zip(nbreaks,nbreaks[1:]):
        for i,interval in events[a]:
            if interval is None:active.pop(i)
            else:active[i]=interval
        intervals=sorted(active.values())
        edge=Q(C.lo,S)
        for left,right in intervals:
            assert left<=edge,('lambda gap',a,b,edge,left)
            edge=max(edge,right)
        assert edge>=Q(1,2)
    result=dict(status='INDEPENDENT EXACT PASS',checker=Path(__file__).name,checker_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),exponent_interval=[str(nbreaks[0]),str(nbreaks[-1])],boxes=len(rows),subboxes=sub,vertical_strips=len(nbreaks)-1,sha256=hashlib.sha256(path.read_bytes()).hexdigest(),seconds=time.time()-start)
    path.with_name('parent_'+path.stem+'_verification.json').write_text(json.dumps(result,indent=2));print(json.dumps(result),flush=True)

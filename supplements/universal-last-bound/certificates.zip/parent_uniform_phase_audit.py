"""Independent integer-interval audit of all-contraction phase slabs."""
from parent_cubic_cover_verify import B,S
from parent_phase_audit import log_range,C
from fractions import Fraction as Q
from functools import lru_cache
from pathlib import Path
import json,hashlib,time,sys
BASE=Path(__file__).parent

def coeff(d,w,upper=False):
    a=[0]*(d+1)
    for j in range(d):
        if w>>(d-j-1)&1:a[j]+=1;a[j+1]-=1
    a[-1]+=int(upper)
    return tuple(a)

def check_slab(row):
    lo,hi=Q(row['lo']),Q(row['hi']);L=B(lo,hi);mid=B((lo+hi)/2);rad=B(-(hi-lo)/2,(hi-lo)/2)
    small='minimum_exponent' in row
    minimum_scale=row['minimum_scale'];endpoint_depth=row['endpoint_depth']
    if not small:assert minimum_scale==100000 and endpoint_depth==9
    def power(x,k):return x**k if k>=0 else B(1)/(x**(-k))
    def evaluate(a,x,shift=0,derivative=False):
        out=B(0)
        for j,z in enumerate(a):
            k=j+shift
            if derivative:z*=k;k-=1
            if z:out=out+z*power(x,k)
        return out
    @lru_cache(None)
    def prefix(d,w,upper=False):
        a=coeff(d,w,upper)
        return evaluate(a,mid)+rad*evaluate(a,L,derivative=True)
    @lru_cache(None)
    def source(p,w,d,vw,h):
        a=prefix(p,w)*power(L,-h);width=power(L,p-h)
        v=prefix(d,vw);V=prefix(d,vw,True);vwth=L**d
        return a,width,v,V,vwth
    def overlap(beta,first,second,h,period_delta=0,finite_scale=None):
        p,w,d,vw,k=first;P,W,D,V,K=second
        ac=coeff(p,w,True);bc=coeff(P,W)
        ac=tuple((ac[j] if j<len(ac) else 0)-(bc[j] if j<len(bc) else 0) for j in range(max(len(ac),len(bc))))
        numerator=coeff(D,V,True);denominator=coeff(d,vw)
        nc=evaluate(numerator,mid);dc=evaluate(denominator,mid)
        shift=K-k-period_delta
        if finite_scale is None:
            firstvalue=beta*evaluate(ac,mid,-h)
            firstderivative=beta*evaluate(ac,L,-h,True)
        else:
            top=coeff(p,w,True);bottom=coeff(P,W);Z=B(finite_scale)
            ratio=(Z+evaluate(top,mid,-h))/(Z+evaluate(bottom,mid,-h))
            firstvalue=beta*Z*log_range(ratio.lo,ratio.hi)
            firstderivative=beta*Z*(evaluate(top,L,-h,True)/(Z+evaluate(top,L,-h))-evaluate(bottom,L,-h,True)/(Z+evaluate(bottom,L,-h)))
        value=firstvalue+log_range(nc.lo,nc.hi)-log_range(dc.lo,dc.hi)-shift*log_range(mid.lo,mid.hi)
        derivative=firstderivative+evaluate(numerator,L,derivative=True)/evaluate(numerator,L)-evaluate(denominator,L,derivative=True)/evaluate(denominator,L)-shift*(B(1)/L)
        return value+rad*derivative
    endpoints=[prefix(endpoint_depth,w) for w in range(2**endpoint_depth)];pieces=[];count=0
    if small:
        minimum_exponent=row['minimum_exponent']
        if 'fixed_exponent' in row:
            assert minimum_exponent==row['fixed_exponent']==endpoint_depth
            assert minimum_scale<=hi**(-minimum_exponent)
            assert Q(row['reduced_lower'])<=max(Q(1),row['target_exponent_cutoff']*lo**minimum_exponent)
        else:assert (B(minimum_scale)*C**(minimum_exponent-1)).lo>S
    for record in row['cycles']:
        beta=B(Q(int(record['beta_fixed'][0]),2**80),Q(int(record['beta_fixed'][1]),2**80));h=record['height'];assert h in (0,1,2)
        error=Q(1,400 if h==2 else 800);factor=Q(1,8000 if h==2 else 10000);umin=Q(3,5) if h==2 else Q(3,10)
        if small:
            error=Q(0);factor=power(L,-h)/(minimum_scale*umin)
        else:
            assert (power(L,-1-2*h)/(200000*umin**2)).hi<B(error).lo
            assert (power(L,-h)/(100000*umin)).hi<B(factor).lo
        cycle=record['cycle'];assert cycle
        for p,w,d,vw,k in cycle:
            a,aw,v,V,width=source(p,w,d,vw,h)
            low=width/(V*beta*aw);high=width/(v*beta*aw)*(1+factor)
            if high.hi<S:low,high=B(1)/high,B(1)/low
            assert low.lo>S
            band0=low.lo>(B(1)/L-1-L).hi and high.hi<(B(1)/(1-L)).lo
            band1=low.lo>(B(1)/L-1).hi and high.hi<(B(1)/(1-L-L*L)).lo
            assert band0 or band1
            assert (beta*aw/(1+factor)+log_range(V.lo,V.hi)-log_range(v.lo,v.hi)-error).lo>0
        for i,first in enumerate(cycle):
            second=cycle[(i+1)%len(cycle)];closing=int(i+1==len(cycle))
            assert (overlap(beta,first,second,h,closing)-error).lo>0,('forward',i)
            assert (overlap(beta,second,first,h,-closing)-error).lo>0,('reverse',i)
            if small:
                assert overlap(beta,first,second,h,closing,minimum_scale*umin).lo>0,('finite forward',i)
                assert overlap(beta,second,first,h,-closing,minimum_scale*umin).lo>0,('finite reverse',i)
        count+=len(cycle)
        for word,u in enumerate(endpoints):
            if small and word % 2**max(0,endpoint_depth-(minimum_exponent-h)):continue
            if Q(u.lo,S)>=umin:
                pieces.append(((B(Q(u.hi,S))*Q(beta.lo,S)).hi,(B(Q(u.lo,S))*Q(beta.hi,S)).lo))
    cursor=B(Q(row.get('reduced_lower','1'))).lo
    for a,b in sorted(pieces):
        if a>cursor:break
        cursor=max(cursor,b)
    assert cursor>=(B(1)/L).hi,('t_gap',float(Q(cursor,S)))
    return count

if __name__=='__main__':
    path=BASE/(sys.argv[1] if len(sys.argv)>1 else 'adversarial_phase_uniform.jsonl');rows=[json.loads(x) for x in path.read_text().splitlines() if x]
    edge=Q(C.lo,S);total=0;start=time.time()
    for i,row in enumerate(rows):
        assert Q(row['lo'])<=edge
        total+=check_slab(row);edge=max(edge,Q(row['hi']))
        print('independent slab PASS',i+1,'sources',total,'seconds',round(time.time()-start,1),flush=True)
    assert edge==Q(1,2)
    minimum_scale=rows[0]['minimum_scale'];assert all(r['minimum_scale']==minimum_scale and Q(r.get('reduced_lower','1'))==1 for r in rows)
    assert (B(3*minimum_scale)*C).lo>minimum_scale*S
    result=dict(status='INDEPENDENT EXACT PASS',slabs=len(rows),sources=total,minimum_exponent=3*minimum_scale,minimum_scale=minimum_scale,scope='all lambda in [c,1/2]',sha256=hashlib.sha256(path.read_bytes()).hexdigest())
    output='parent_uniform_phase_verification.json' if len(sys.argv)==1 else 'parent_'+path.stem+'_verification.json'
    (BASE/output).write_text(json.dumps(result,indent=2));print(json.dumps(result),flush=True)

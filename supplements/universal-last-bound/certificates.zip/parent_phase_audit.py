"""Independent audit of finite large-exponent phase certificates at c.

Uses integer intervals with denominator 10^60 and a separate logarithm
series implementation. Does not import the phase or return generators.
"""
from parent_cubic_cover_verify import B,S,cylinder
from fractions import Fraction as Q
from functools import lru_cache
from pathlib import Path
import json,gzip,sys,heapq

BASE=Path(__file__).parent
lower=Q('0.366025403784438646763723170752936183471402626905190314027903')
C=B(lower,lower+Q(1,10**60))
assert (2*lower+1)**2<3<(2*(lower+Q(1,10**60))+1)**2

def log_point(x):
    if x==1:return B(0)
    if x<1:return -log_point(1/x)
    z=B((x-1)/(x+1));power=z;total=B(0)
    for k in range(110):
        total=total+2*power/(2*k+1)
        power=power*z*z
    remainder=2*power/(221*(1-z*z))
    return B(total.lo,total.hi+remainder.hi,True)

@lru_cache(None)
def log_range(lo,hi):
    return B(log_point(Q(lo,S)).lo,log_point(Q(hi,S)).hi,True)
T=-log_range(C.lo,C.hi)

@lru_cache(None)
def cp(k):return C**k if k>=0 else B(1)/cp(-k)
@lru_cache(None)
def prefix(d,w):return cylinder(w,d,C)[0]

def check_table():
    table={}
    for row in json.loads((BASE/'adversarial_return_band_table.json').read_text()):
        r=B(*map(Q,row['slopes']));a,b=map(Q,row['domain']);mu=Q(row['target_inset'])
        assert row['margin_is_physical'] and row['depth']==4
        events=[]
        for wx in range(16):
            for wy in range(16):
                z=prefix(4,wx)+r*prefix(4,wy)
                left=(z+cp(4)*a+mu).hi;right=(z+cp(4)*b-mu).lo
                if left>right:continue
                events.append((left,1));events.append((right,-1))
        events.sort(key=lambda e:(e[0],-e[1]))
        count=0;last=None
        al=B(a).lo;bh=B(b).hi
        for point,change in events:
            if last is not None and max(last,al)<min(point,bh):assert count>=2
            count+=change;last=point
        assert (C*b).lo>B(a).hi and (2*B(b)-1-r-mu).lo>0
        idx=int(Q(row['slopes'][0])*1000)
        table[idx]=mu
    return table

@lru_cache(None)
def source(p,w,d,vw,h):
    a=prefix(p,w)*cp(-h);width=cp(p-h);v=prefix(d,vw);vwth=cp(d)
    V=v+vwth
    return a,width,v,vwth,log_range(v.lo,v.hi),log_range(V.lo,V.hi)

def check_cycle(row,table):
    beta=B(Q(int(row['beta_fixed'][0]),2**80),Q(int(row['beta_fixed'][1]),2**80))
    h=row['height'];practical=row.get('analytic_derivative_band',False)
    assert h in ((0,1,2) if practical else (2,3)) and beta.hi<35*S
    phase_error=Q(1,400 if h==2 else 800) if practical else Q(1,10**5)
    derivative_factor=Q(1,8000 if h==2 else 10000) if practical else Q(21,8*10**8)
    if practical:
        umin=Q(3,5) if h==2 else Q(3,10)
        assert (cp(-1)*cp(-h)**2/(2*100000*umin**2)).hi<B(phase_error).lo
        assert (cp(-h)/(100000*umin)).hi<B(derivative_factor).lo
    expressions=[]
    for p,w,d,vw,shift in row['cycle']:
        a,width,v,vwidth,lv,lV=source(p,w,d,vw,h)
        # Direct nonlinear derivative-band theorem; no reference slope error.
        low=vwidth/((v+vwidth)*beta*width)
        high=vwidth/(v*beta*width)*(1+derivative_factor)
        if high.hi<S:low,high=B(1)/high,B(1)/low
        assert low.lo>S
        band0=(low.lo>(B(1)/C-1-C).hi and high.hi<(B(1)/(1-C)).lo)
        band1=(low.lo>(B(1)/C-1).hi and high.hi<(B(1)/(1-C-C*C)).lo)
        assert band0 or band1
        expressions.append((a,width,lv,lV,shift))
    a,width,lv,lV,shift=expressions[0]
    assert (beta*a-lV-shift*T).hi<0
    a,width,lv,lV,shift=expressions[-1]
    assert (beta*(a+width)-lv-shift*T-phase_error).lo>T.hi
    for previous,current in zip(expressions,expressions[1:]):
        overlap=beta*(previous[0]+previous[1]-current[0])+current[3]-previous[2]+(current[4]-previous[4])*T-phase_error
        assert overlap.lo>0

if __name__=='__main__':
    table=check_table();print('independent return table PASS',len(table),flush=True)
    if '--table-only' in sys.argv:raise SystemExit
    practical='--practical' in sys.argv
    if practical:
        status=json.loads((BASE/'adversarial_phase_practical.json').read_text());rows=status['cycles']
    else:
        with gzip.open(BASE/'adversarial_phase_reuse.jsonl.gz','rt') as f:rows=[json.loads(x) for x in f if x.strip()]
        status=json.loads((BASE/'adversarial_phase_reuse_status.json').read_text())
    for i,row in enumerate(rows):
        check_cycle(row,table)
        if i%100==0:print('independent cycles',i+1,flush=True)
    # Reconstruct reduced-t coverage using all certified depth-eight endpoints.
    depth=status['endpoint_depth'];assert depth<=12
    endpoints=[prefix(depth,w) for w in range(2**depth)]
    endpoints=[u for u in endpoints if u.lo*25>=2*S]
    coverage=[];target=(B(1)/C).hi
    for row in rows:
        low,high=map(int,row['beta_fixed'])
        threshold=Q(3,5) if practical and row['height']==2 else Q(3,10) if practical else Q(2,25)
        intervals=[(-((-u.hi*low)//2**80),u.lo*high//2**80) for u in endpoints if Q(u.lo,S)>=threshold]
        merged=[]
        for a,b in heapq.merge(coverage,intervals):
            if b<S or a>target:continue
            if merged and a<=merged[-1][1]:merged[-1]=(merged[-1][0],max(b,merged[-1][1]))
            else:merged.append((a,b))
        coverage=merged
    edge=S
    for a,b in coverage:
        if a>edge:break
        edge=max(edge,b)
    target=(B(1)/C).hi
    report={'cycles_verified':len(rows),'minimum_scale':status['minimum_scale'],'table_boxes_verified':len(table),'full_t_cover':edge>=target,
            'first_gap_lower':str(Q(edge,S)),'scope':'lambda=c only'}
    (BASE/('parent_practical_phase_verification.json' if practical else 'parent_phase_verification.json')).write_text(json.dumps(report,indent=2))
    print(json.dumps(report),flush=True)

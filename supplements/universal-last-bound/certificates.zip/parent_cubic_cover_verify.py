"""Independent cubic certificate audit. Integer outward arithmetic only.

No imports from the search/production validator. Natural interval evaluation
with dyadic subdivision, independent corner construction and chain checking.
Every interval stores lower/upper integers divided by 10**60.
"""
import json, sys, hashlib, time,math
from fractions import Fraction
from pathlib import Path

S=10**60
def ceildiv(a,b): return -((-a)//b)
class B:
    def __init__(self,lo,hi=None,raw=False):
        if raw:self.lo,self.hi=lo,hi
        else:
            lo=Fraction(lo);hi=lo if hi is None else Fraction(hi)
            self.lo=lo.numerator*S//lo.denominator
            self.hi=ceildiv(hi.numerator*S,hi.denominator)
    def __add__(self,v):
        if not isinstance(v,B):v=B(v)
        return B(self.lo+v.lo,self.hi+v.hi,True)
    __radd__=__add__
    def __neg__(self):return B(-self.hi,-self.lo,True)
    def __sub__(self,v):return self+-v if isinstance(v,B) else self+B(-Fraction(v))
    def __rsub__(self,v):return -self+v
    def __mul__(self,v):
        if not isinstance(v,B):v=B(v)
        vals=[a*b for a in (self.lo,self.hi) for b in (v.lo,v.hi)]
        return B(min(vals)//S,ceildiv(max(vals),S),True)
    __rmul__=__mul__
    def __truediv__(self,v):
        if not isinstance(v,B):v=B(v)
        assert v.lo>0
        return self*B(S*S//v.hi,ceildiv(S*S,v.lo),True)
    def __pow__(self,k):
        k=Fraction(k)
        assert k>=0 and self.lo>=0
        if k==0:return B(1)
        if k.denominator!=1:
            p,q=k.numerator,k.denominator
            def root(v):
                target=v**p*S**(q-p) if q>=p else v**p//S**(p-q)
                if q==2:return math.isqrt(target)
                low,high=0,1<<((target.bit_length()+q-1)//q)
                while high-low>1:
                    middle=(low+high)//2
                    if middle**q<=target:low=middle
                    else:high=middle
                return low
            return B(root(self.lo),root(self.hi)+1,True)
        k=k.numerator
        return B(self.lo**k//S**(k-1),ceildiv(self.hi**k,S**(k-1)),True)

def cylinder(w,d,l):
    # Direct positional sum; independent of production Horner implementation.
    out=B(0);power=B(1)
    for j in range(d):
        if (w>>(d-1-j))&1:out=out+(1-l)*power
        power=power*l
    return out,out+l**d

def verify_box(lo,hi,rec):
    l=B(lo,hi);p,q=rec['p'],rec['q']
    x,X=cylinder(rec['wx'],p,l);y,Y=cylinder(rec['wy'],q,l)
    n=Fraction(rec.get('n',3))
    if (x**n+y**n).hi>=S or (X**n+Y**n).lo<=S:return False
    dx0=l**p*x**(n-1);dx1=l**p*X**(n-1);dy0=l**q*y**(n-1);dy1=l**q*Y**(n-1)
    if rec['kind']=='narrow':
        return any(mt.lo>Ms.hi and (l*mt-(1-l-l**2)*Ms).lo>0 and (l*ms-(1-2*l)*Mt).lo>0
                   for ms,Ms,mt,Mt in ((dx0,dx1,dy0,dy1),(dy0,dy1,dx0,dx1)))
    if rec['kind']=='analytic_band':
        ms,Ms,mt,Mt=(dy0,dy1,dx0,dx1) if rec['swapped'] else (dx0,dx1,dy0,dy1)
        low=mt/Ms;high=Mt/ms
        if low.lo<=S:return False
        lower=B(1)/l-1-l if rec['band']==0 else B(1)/l-1
        upper=B(1)/(1-l) if rec['band']==0 else B(1)/(1-l-l*l)
        return low.lo>lower.hi and high.hi<upper.lo
    assert rec['kind']=='returns'
    r=Fraction(rec['r']);mu=Fraction(rec['mu']);a=Fraction(rec.get('a','403/1000'));b=1+r-a
    depth=rec.get('depth',4)
    den=(dy0+dy1)/2 if rec['swapped'] else (dx0+dx1)/2
    cx=r if rec['swapped'] else 1;cy=1 if rec['swapped'] else r
    xx=B(dx0.lo,dx1.hi,True)/den-cx;yy=B(dy0.lo,dy1.hi,True)/den-cy
    error=max(abs(xx.lo),abs(xx.hi))+max(abs(yy.lo),abs(yy.hi))
    if Fraction(error,S)>=mu:return False
    if Fraction((l*b).lo,S)<=a or 2*b<=1+r+Fraction(error,S):return False
    assert len(rec['chains'])==2
    assert set(rec['chains'][0]).isdisjoint(rec['chains'][1])
    for chain in rec['chains']:
        assert len(chain)==len(set(chain)) and all(0<=w<4**depth for w in chain)
        reach=B(a).lo
        for w in chain:
            # Decode as a pair of binary cylinder words, not affine digits.
            wx=wy=0
            for j in range(depth):
                digit=(w>>(2*(depth-1-j)))&3
                wx=2*wx+(digit&1);wy=2*wy+(digit>>1)
            z=cylinder(wx,depth,l)[0]+r*cylinder(wy,depth,l)[0]
            start=z+l**depth*a+mu;stop=z+l**depth*b-mu
            if start.hi>=reach:return False
            reach=stop.lo
        if Fraction(reach,S)<=b:return False
    return True

def audit(lo,hi,rec,depth=0):
    if verify_box(lo,hi,rec):return 1,depth
    if depth>=18:raise AssertionError(('unverified',lo,hi,rec))
    mid=(lo+hi)/2
    n,d=audit(lo,mid,rec,depth+1);m,e=audit(mid,hi,rec,depth+1)
    return n+m,max(d,e)

if __name__=='__main__':
    exponent=Fraction(sys.argv[2]) if len(sys.argv)>2 else Fraction(3)
    path=Path(__file__).with_name(sys.argv[3] if len(sys.argv)>3 else f'n{exponent}_global_cover.jsonl')
    data=path.read_bytes();rows=[json.loads(line) for line in data.splitlines() if line]
    if len(sys.argv)>1 and int(sys.argv[1])>0:rows=rows[:int(sys.argv[1])]
    first=Fraction(rows[0]['lo']);edge=Fraction(rows[0]['hi'])
    assert 0<first<edge<1/2
    if exponent==3:assert (2*first+1)**2<3<(2*edge+1)**2
    started=time.time();total=maximum=0
    for i,rec in enumerate(rows):
        assert Fraction(rec.get('n',3))==exponent,('record exponent mismatch',i)
        lo,hi=Fraction(rec['lo']),min(Fraction(rec['hi']),Fraction(1,2))
        if lo>=Fraction(1,2):break
        assert lo<hi and lo<=edge
        count,depth=audit(lo,hi,rec);total+=count;maximum=max(maximum,depth)
        edge=max(edge,hi)
        if i%25==0:print('checked',i+1,'subboxes',total,'right',float(edge),'seconds',round(time.time()-started,1),flush=True)
    out={'status':'PASS','exponent':str(exponent),'left_exact':str(first),'patches':len(rows),'subboxes':total,'max_bisection_depth':maximum,
         'right_exact':str(edge),'right_float':float(edge),'snapshot_sha256':hashlib.sha256(data).hexdigest(),
         'arithmetic':'outward integer intervals, denominator 10^60','elapsed_seconds':time.time()-started}
    outfile='parent_cubic_cover_verification.json' if exponent==3 else f'parent_n{exponent}_cover_verification.json'
    if len(sys.argv)>3:outfile='parent_'+path.stem+'_verification.json'
    Path(__file__).with_name(outfile).write_text(json.dumps(out,indent=2))
    print(json.dumps(out),flush=True)

"""Independent shell coverage and phase replay; depends on audited M1000 tail."""
from parent_uniform_phase_audit import check_slab,C,S,B,Q,BASE
import json,sys,time,hashlib
path=BASE/(sys.argv[1] if len(sys.argv)>1 else 'adversarial_finite_shells_N1000.jsonl')
rows=[json.loads(x) for x in path.read_text().splitlines() if x];N=rows[0]['target_exponent_cutoff'];total=0;start=time.time()
for i,row in enumerate(rows):
    assert row['target_exponent_cutoff']==N and row['tail_minimum_scale']==1000
    total+=check_slab(row)
    if i%4==0:print('shellslabs',i+1,'sources',total,'seconds',round(time.time()-start,1),flush=True)
assert (B(N)*C**6).lo>S # No scale index m<=5 can have n>=N.
assert 2**10>1000 # No m>=10 can have M<1000 when lambda<=1/2.
for m in range(6,10):
    intervals=sorted((Q(r['lo']),Q(r['hi'])) for r in rows if r['fixed_exponent']==m)
    assert intervals
    left,edge=intervals[0]
    assert left<=Q(C.lo,S) or 1000*left**m<=1
    for a,b in intervals[1:]:
        assert a<=edge,('shell gap',m,edge,a)
        edge=max(edge,b)
    assert edge>=Q(1,2) or N*edge**(m+1)>=1
assert {r['fixed_exponent'] for r in rows}=={6,7,8,9}
tail=json.loads((BASE/'parent_adversarial_phase_small_M1000_D7_verification.json').read_text())
assert tail['status']=='INDEPENDENT EXACT PASS' and tail['minimum_scale']==1000
tailpath=BASE/'adversarial_phase_small_M1000_D7.jsonl'
assert hashlib.sha256(tailpath.read_bytes()).hexdigest()==tail['sha256']
result=dict(status='INDEPENDENT EXACT PASS',minimum_exponent=N,slabs=len(rows),sources=total,scale_indices=[6,7,8,9],tail_dependency_sha256=tail['sha256'],sha256=hashlib.sha256(path.read_bytes()).hexdigest(),seconds=time.time()-start)
path.with_name('parent_'+path.stem+'_verification.json').write_text(json.dumps(result,indent=2));print(json.dumps(result),flush=True)

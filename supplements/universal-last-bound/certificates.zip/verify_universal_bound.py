"""R021 final dependency check; --replay reruns every required exact checker.

The algebraic reductions and analytic source theorem are mathematical inputs;
see UNIVERSAL_BOUND_PROOF.md and the three supporting proof reports.
No floating-point search is required to verify the stored certificates.
"""
from pathlib import Path
from fractions import Fraction
import argparse, hashlib, json, subprocess, sys, time

BASE = Path(__file__).resolve().parent
CONTINUOUS = [
    ('small', '6/5', '2'), ('medium', '2', '10'),
    ('high', '10', '100'), ('bridge', '100', '250'),
    ('upper', '250', '500'),
]

def report(name):
    value = json.loads((BASE / name).read_text(encoding='utf-8'))
    assert value['status'] in ('PASS', 'INDEPENDENT EXACT PASS'), name
    return value

def digest(name):
    return hashlib.sha256((BASE / name).read_bytes()).hexdigest()

def run_replay():
    commands = [('parent_near_one_audit.py',)]
    for exponent, stem in [('7/6', 'n7_6'), ('6/5', 'n6_5')]:
        commands.append(('parent_cubic_cover_verify.py', '0', exponent, stem+'_analytic_cover.jsonl'))
    commands += [('parent_continuous_tight_audit.py' if kind=='upper' else 'parent_continuous_cover_audit.py', 'continuous_'+kind+'_n_cover.jsonl')
                 for kind, _, _ in CONTINUOUS]
    commands += [('parent_uniform_phase_audit.py', 'adversarial_phase_small_M1000_D7.jsonl'),
                 ('parent_finite_shell_audit.py', 'adversarial_finite_shells_N500.jsonl')]
    with (BASE / 'universal_bound_replay.log').open('w', encoding='utf-8') as log:
        for command in commands:
            print('Verifying:', ' '.join(command), flush=True)
            log.write('\nCOMMAND: '+' '.join(command)+'\n'); log.flush()
            subprocess.run([sys.executable, '-X', 'utf8', str(BASE / command[0]), *command[1:]],
                           cwd=BASE, stdout=log, stderr=subprocess.STDOUT, check=True)

def main():
    if sys.flags.optimize:
        raise RuntimeError('Run Python without -O or -OO: exact checks require assertions.')
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--replay', action='store_true')
    options = parser.parse_args()
    if options.replay:
        run_replay()
    dependencies = []
    for name in ['parent_near_one_verification.json', 'parent_near_one_six_fifths_verification.json']:
        report(name)
        dependencies.append(dict(report=name, sha256=digest(name)))
    for exponent, stem in [('7/6', 'n7_6'), ('6/5', 'n6_5')]:
        name = stem+'_analytic_cover.jsonl'
        value = report('parent_'+stem+'_analytic_cover_verification.json')
        assert value['exponent'] == exponent
        assert Fraction(value['right_exact']) == Fraction(1, 2)
        # 0.366 is strictly below (sqrt(3)-1)/2.
        assert Fraction(value['left_exact']) < Fraction(366, 1000)
        assert value['snapshot_sha256'] == digest(name)
        dependencies.append(dict(data=name, sha256=digest(name)))
    previous = Fraction(6, 5)
    for kind, left, right in CONTINUOUS:
        name = 'continuous_'+kind+'_n_cover.jsonl'
        value = report('parent_continuous_'+kind+'_n_cover_verification.json')
        assert value['exponent_interval'] == [left, right]
        assert Fraction(left) == previous
        previous = Fraction(right)
        assert value['sha256'] == digest(name)
        rows = [json.loads(line) for line in (BASE/name).read_text().splitlines() if line]
        assert len(rows) == value['boxes']
        for row in rows:
            assert row.get('source', 'endpoint') in ('endpoint', 'log_endpoint', 'actual')
            assert row['band'] in (0, 1) and isinstance(row['swapped'], bool)
            for depth_key, word_key in [('p', 'wx'), ('q', 'wy')]:
                assert type(row[depth_key]) is int and row[depth_key] >= 1
                assert type(row[word_key]) is int and 0 <= row[word_key] < 2**row[depth_key]
            if row.get('source') != 'actual':
                assert type(row['j']) is int and type(row['k']) is int and row['k'] >= 0
        dependencies.append(dict(data=name, sha256=digest(name),
                                 exponent_interval=[left, right], boxes=value['boxes']))
    assert previous == 500
    tail_name = 'adversarial_phase_small_M1000_D7.jsonl'
    tail = report('parent_adversarial_phase_small_M1000_D7_verification.json')
    assert tail['minimum_scale'] == 1000 and tail['sha256'] == digest(tail_name)
    shell_name = 'adversarial_finite_shells_N500.jsonl'
    shell = report('parent_adversarial_finite_shells_N500_verification.json')
    assert shell['minimum_exponent'] == 500 and shell['scale_indices'] == [6, 7, 8, 9]
    assert shell['tail_dependency_sha256'] == tail['sha256']
    assert shell['sha256'] == digest(shell_name)
    dependencies += [dict(data=name, sha256=digest(name)) for name in (tail_name, shell_name)]
    result = dict(status='COMPLETE VERIFIED DEPENDENCY CHAIN',
                  scope='Every real n>1 and every (sqrt(3)-1)/2<=lambda<=1/2',
                  statement='dim_H E_(n,lambda)>0; hence lambda_max(n)<=(sqrt(3)-1)/2',
                  exact_replay_performed=options.replay,
                  dependencies=dependencies,
                  verifier_sha256={name:digest(name) for name in [
                      'verify_universal_bound.py', 'parent_near_one_audit.py',
                      'parent_cubic_cover_verify.py', 'parent_phase_audit.py',
                      'parent_continuous_cover_audit.py',
                      'parent_continuous_tight_audit.py',
                      'parent_uniform_phase_audit.py', 'parent_finite_shell_audit.py']},
                  mathematical_inputs=['analytic all-interior source theorem',
                      'near-one coefficient-grid and monotonicity reductions',
                      'continuous exponent endpoint reductions and scale transfer',
                      'finite-phase tail reduction and endpoint-cylinder legality'])
    (BASE / 'universal_bound_verification.json').write_text(
        json.dumps(result, indent=2), encoding='utf-8')
    print(json.dumps(result, indent=2))

if __name__ == '__main__':
    main()

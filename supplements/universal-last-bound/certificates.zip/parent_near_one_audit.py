from parent_cubic_cover_verify import B,S
from parent_phase_audit import C
from fractions import Fraction as Q
from math import gcd
from pathlib import Path
import json

assert Q(97,56)**2>3
assert Q(1067,1120)**21<Q(183,500)<Q(C.lo,S)
assert Q(9,25)**7>Q(1391,1500)**100
exceptions=sorted(set(Q(p,q) for q in range(1,21) for p in range(q+1,11*q//10+1) if gcd(p,q)==1 and Q(p,q)>Q(107,100)))
assert exceptions==sorted(map(Q,['11/10','12/11','13/12','14/13','15/14']))
for n,j in [(Q(12,11),4),(Q(13,12),4),(Q(15,14),5)]:
    z=B(1)/(C**Q(j,n.denominator))
    assert z.lo>(B(1)/C-1-C).hi
    assert z.hi<(B(1)/(n*(1-C))).lo
for n,t in [(Q(11,10),Q(2,5)),(Q(14,13),Q(5,13))]:
    low=(1-C)**(n-1)/(C**t)
    high=(1-C+C*C)**(n-1)/(C**t)
    assert low.lo>(B(1)/C-1-C).hi
    assert high.hi<(B(1)/(1-C)).lo
    assert (n*C**t-(1-C)**n).lo>0
    assert (B(Q(3,4))**n-n*B(Q(1,2))**t*(1-C*C)).lo>0
    assert n-1+t<1 and t>n-1
report=dict(status='INDEPENDENT EXACT PASS',scope='all real 1<n<=11/10, all c<=lambda<=1/2',exceptions=[str(x) for x in exceptions])
Path(__file__).with_name('parent_near_one_verification.json').write_text(json.dumps(report,indent=2));print(json.dumps(report))

# Further independent checks for the n<=6/5 extension.
points=[Q(C.lo,S)]+[Q(j,100) for j in (38,40,42,44,46,48,50)]
assert ((1-C)**Q(1,5)/(C**Q(21,50))-(B(1)/C-1-C)).lo>0
assert (B(1)/(1-C)-(1-C+C*C)**Q(1,10)/(C**Q(47,100))).lo>0
assert (Q(11,10)*C**Q(47,100)-(1-C)**Q(11,10)).lo>0
for a,b in zip(points,points[1:]):
    assert (B(1-b+b*b)**Q(6,5)-Q(6,5)*B(b)**Q(21,50)*(1-a*a)).lo>0
assert Q(21,50)>Q(1,5) and Q(1,5)+Q(47,100)<1 and Q(47,100)-Q(21,50)>Q(1,21)
exceptions=sorted(set(Q(p,q) for q in range(1,21) for p in range(q+1,6*q//5+1) if gcd(p,q)==1 and Q(p,q)>Q(11,10)))
remaining=[n for n in exceptions if not any(Q(21,50)<Q(j,n.denominator)<Q(47,100) for j in range(1,n.denominator))]
for n,t in [(Q(19,17),Q(8,17)),(Q(9,8),Q(3,8)),(Q(20,17),Q(8,17))]:
    assert ((1-C)**(n-1)/(C**t)-(B(1)/C-1-C)).lo>0
    assert (B(1)/(1-C)-(1-C+C*C)**(n-1)/(C**t)).lo>0
    assert (n*C**t-(1-C)**n).lo>0
    for a,b in zip(points,points[1:]):
        assert (B(1-b+b*b)**n-n*B(b)**t*(1-a*a)).lo>0
    assert t>n-1 and n-1+t<1
    remaining.remove(n)
assert remaining==[Q(7,6),Q(6,5)]
report=dict(status='INDEPENDENT EXACT PASS',scope='analytic extension to n<=6/5 except separately certified7/6,6/5',exception_count=len(exceptions),remaining=[str(x) for x in remaining])
Path(__file__).with_name('parent_near_one_six_fifths_verification.json').write_text(json.dumps(report,indent=2));print(json.dumps(report))
